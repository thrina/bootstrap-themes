$(".trigger").click(function(){
  alert(123);
});